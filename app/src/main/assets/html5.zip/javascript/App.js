import React from 'react';
import ReactDom from 'react-dom';
import RouterConfig from './RouterConfig';
import Utils from 'fyBase/common/Utils';
import Cache from 'fyBase/common/CacheHandle';
import "fyBase/common/Dispatcher";
window.location.type="forward";
if(window.isNative) {
  window.Cache=Cache;
  // Cache.init();
  Utils.initialGlobalMethods();   //初始化全局方法
  ReactDom.render((RouterConfig),document.getElementById("root-container"))
}else{
	//刷新页面，首次价值，从首页开始
	window.location.hash = "";
	Utils.initialGlobalMethods();
	ReactDom.render((RouterConfig),document.getElementById("root-container"))
}
